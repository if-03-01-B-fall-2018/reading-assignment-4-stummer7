# if.03.01-05 Basic Web Techniques -- Advanced Css
This reading assignment shall make you familiar with the more advanced Css topics like classes and id's, the css box model and floating. Go through the topics named in the document [ReadingAssignment.md](ReadingAssignment.md). Read the pages linked there.

Make sure that you read the section *Required Tasks* in [ReadingAssignment.md](ReadingAssignment.md) carefully and to complete all the tasks listed there.

Finally you can go through the questions in [SampleQuestions.md](SampleQuestions.md) to check your understanding and to prepare for the quiz.
