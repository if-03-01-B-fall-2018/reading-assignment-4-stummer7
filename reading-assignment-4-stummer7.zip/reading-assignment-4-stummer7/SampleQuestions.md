### IF.03.01 Basic Web Techniques
# Reading Assignment 1: Advanced CSS

## Box Model
1. Block elements have which kind of characteristics?
2. Inline elements have which kind of characteristics?
2. What is the margin of an Html element? Where can one find it?
3. What is the padding of an Html element? How does it differ from margin?

## Classes and Ids
   1. Write down a selector for a certain class
   1. Write down a selector for a certain html element of a certain class
   1. Write down a selector for a certain id
   1. Write down a selector for a certain html element of a certain id
   4. Write down the start tag of a certain html element with a specific class.
   4. Write down the start tag of a certain html element with a specific id.
   5. Do classes select one or more elements?
   6. Do ids select one or more elements?
   7. How often can classes / ids occur on one page?

## Floating
   1. Write down the css declaration to make an html element float to the left
   2. Make an html element stop floating around another (for a specific direction, for all directions)
